package com.codecool.dungeoncrawl.ui;

import com.codecool.dungeoncrawl.data.Drawable;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.image.Image;

import java.util.HashMap;
import java.util.Map;

public class Tiles {
    public static int TILE_WIDTH = 32;

    private static Image tileset = new Image("/tiles.png", 543 * 2, 543 * 2, true, false);
    private static Map<String, Tile> tileMap = new HashMap<>();
    public static class Tile {
        public final int x, y, w, h;
        Tile(int i, int j) {
            x = i * (TILE_WIDTH + 2);
            y = j * (TILE_WIDTH + 2);
            w = TILE_WIDTH;
            h = TILE_WIDTH;
        }
    }

    static {
        tileMap.put("empty", new Tile(0, 0));
        tileMap.put("wall", new Tile(10, 17));
        tileMap.put("floor", new Tile(2, 0));
        tileMap.put("player", new Tile(27, 0));
        tileMap.put("skeleton", new Tile(29, 6));
        tileMap.put("loot", new Tile(8, 6));
        tileMap.put("door", new Tile(3, 3));
        tileMap.put("key", new Tile(16, 23));
        tileMap.put("sword", new Tile(2, 30));
        tileMap.put("potion", new Tile(17, 25));
        tileMap.put("nextFloor", new Tile(3, 6));
        tileMap.put("gnome", new Tile(26, 9));
        tileMap.put("spider", new Tile(29, 5));
        tileMap.put("cultist", new Tile(24, 2));
        tileMap.put("saveTile", new Tile(0,10));
        tileMap.put("loadTile", new Tile(24, 24));
        tileMap.put("chainMail", new Tile(1, 23));
        tileMap.put("crab", new Tile(25, 5));
        tileMap.put("boss", new Tile(30, 2));
        tileMap.put("cat", new Tile(30, 7));
        tileMap.put("queen", new Tile(29, 3));
        tileMap.put("gem", new Tile(23, 4));
        tileMap.put("repo", new Tile(13, 27));
    }

    public static void drawTile(GraphicsContext context, Drawable d, int x, int y) {
        Tile tile = tileMap.get(d.getTileName());
        context.drawImage(tileset, tile.x, tile.y, tile.w, tile.h,
                x * TILE_WIDTH, y * TILE_WIDTH, TILE_WIDTH, TILE_WIDTH);
    }
}
