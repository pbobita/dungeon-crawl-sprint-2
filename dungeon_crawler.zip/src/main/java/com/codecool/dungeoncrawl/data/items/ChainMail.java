package com.codecool.dungeoncrawl.data.items;

import com.codecool.dungeoncrawl.dao.ItemDao;
import com.codecool.dungeoncrawl.data.Cell;
import com.codecool.dungeoncrawl.data.GameMap;
import com.codecool.dungeoncrawl.data.actors.Player;

public class ChainMail extends Item {
    public ChainMail(Cell cell, char symbol) {
        super(cell, symbol);
    }

    @Override
    public String getTileName() {
        return "chainMail";
    }

    @Override
    public void onPickUp(Player player, GameMap map, Cell cell) {
        Integer boost = ItemDao.getIntStat("chainMail", "maxHealthIncrease");
        int max = player.getHealth();
        player.setMaxHealth(max + boost);
        player.setInventory(player.getInventory() + ", chainMail");
        setEquipped(true);
        cell.setItem(null);
    }
}
